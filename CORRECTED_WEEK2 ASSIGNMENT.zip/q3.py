
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OneHotEncoder

m=LogisticRegression()
df=pd.read_csv("corrected train set.csv")
df1=pd.read_csv("week 1 test.csv")
L=[]


for i in range(4):
       s="attribute_"+str(i)
       L.append(s)
for i in range(18):
      s="measurement_"+str(i)
      L.append(s)  
L.append("loading")      
X=df[L]
Y=df["failure"]
X1=df1[L]
c = (X.dtypes == 'object')
cat= list(c[c].index)#or directly cat=["attribute 0","attribute 1"].The other method is more general
OH_en = OneHotEncoder(handle_unknown='ignore', sparse=False)
oh_train = pd.DataFrame(OH_en.fit_transform(X[cat]))
oh_test = pd.DataFrame(OH_en.transform(X1[cat]))


oh_train.index = X.index
oh_test.index = X1.index

num_train = X.drop(cat, axis=1)
num_test = X1.drop(cat, axis=1)

finaltrain = pd.concat([num_train,oh_train], axis=1)
finaltest= pd.concat([num_test,oh_test], axis=1)

m.fit(finaltrain,Y)
pred=m.predict(finaltest)
df1["failure"]=pred
print(df1[["id","failure"]])

