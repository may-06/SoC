import pandas as pd
import numpy as np
import matplotlib as ma
import sympy as sy

(X,Y,b,w)=sy.symbols("X Y b w")
def compute_cost(X,Y,b,w):

    cost=0
    for i in range(3):
        #print(X[i])
        #print(f(X[i]))
        cost+=(f(X[i],b,w)-Y[i])*(f(X[i],b,w)-Y[i])
        #print(cost)
    cost/=2*i  
    return cost

def compute_gradient(X,Y,b,w):
    temp1=sy.diff(compute_cost(X,Y,b,w),b)
    temp2=sy.diff(compute_cost(X,Y,b,w),w)
    f1 = sy.lambdify([b,w],temp1, 'numpy')
    f2 = sy.lambdify([b,w],temp2, 'numpy')
    return([temp1,temp2,f1,f2])

    
    

def f(x,b,w):
     return x*b + w
 
    
def compute_cost_gradient(X,Y,b_init,w_init,a,n):
       b1=b_init
       w1=w_init
       for i in range(n):
           f1= compute_gradient(X,Y,b,w)[2]
           f2 = compute_gradient(X,Y,b,w)[3]
           temp_1=f1(b1,w1)
           temp_2=f2(b1,w1)
           #print(temp_1)
           #print(temp_2)
           b1=b1-a*(temp_1)
           w1=w1-a*(temp_2)
       return([b1,w1]) 
    

Data={"No of years of exp":[1,3,5],"Salary":[300,480,570]}
df=pd.DataFrame(Data)
Y=np.array(df["Salary"])
X=np.array(df["No of years of exp"])

for i in range(3):
    ma.pyplot.scatter(X[i],Y[i],color="red");

print(compute_cost(X,Y,100,200))
x=compute_gradient(X,Y,b,w)
temp1=x[2]
temp2=x[3]
print(temp1(1,1))

#f1 = sy.lambdify(b, temp1, 'numpy')
#f2 = sy.lambdify(w, temp2, 'numpy')
print(compute_cost_gradient(X,Y,0,0,0.1,10000))

