import numpy as np
l=eval(input("Enter a 4x4 array"))
print(l)
a1=np.array(l)
print(a1)
d=[]
for i in range(4):
    d.append(a1[i,i])
print("diagnol elements are {}".format(d))
print(d)
tr=sum(d)
print("Trace is {}".format(tr))
for i in range(4):
    print("min of row {} is {}".format(i,np.min(a1[i])))
    print("max of row {} is {}".format(i,np.max(a1[i])))
    


