import numpy as np
b=np.random.uniform(0,1,size=(4,5))
print(b)

