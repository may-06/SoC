class Hey():
    def __init__(self):
        self.array=[]
    def get_array(self):
        n=int(input("enter number of elements"))
        for i in range(n):
           self.array.append(eval(input("Enter element {} ".format(i+1))))
        return sorted(self.array) 
m=Hey()     
x=m.get_array()
print(x)      