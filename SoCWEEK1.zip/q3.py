import numpy as np
import pandas as pd
df=pd.read_csv("stock.csv")
c=np.array(df[["closing price","date"]])
x=df["date"]
l=[]
for i in x:
    l.append(i[-5]+i[-4])#date format in the file I used dd/mm/yy
#print(x)
df["month"]=l
x=df.groupby("month")
#print(x[["month","closing price"]].head())
L=np.array(df[["month","closing price"]])
l1=np.unique(L[:,0])#finding unique values of month
ar={}
for mon in l1:
     sum = np.sum(L[L[:, 0] == mon, 1])
     count=np.count_nonzero(L[:,0]==mon)
     avg=sum/count
     ar[mon]=avg

print(ar)
